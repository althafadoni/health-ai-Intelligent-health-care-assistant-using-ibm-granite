# HealthAI: Intelligent Healthcare Assistant

HealthAI harnesses IBM Watson Machine Learning and Generative AI to provide intelligent healthcare assistance, offering users accurate medical insights. The platform includes a Patient Chat for answering health-related questions, Disease Prediction that evaluates user-reported symptoms to deliver potential condition details, Treatment Plans that provide personalized medical recommendations, and Health Analytics to visualize and monitor patient health metrics.

## 🏥 Features

### 1. Patient Chat
- **Intelligent Health Q&A**: Ask any health-related questions and receive AI-powered responses
- **Conversation History**: Maintains chat history for context retention
- **Medical Disclaimers**: Ensures users understand the informational nature of responses

### 2. Disease Prediction
- **Symptom Analysis**: Input detailed symptoms for potential condition analysis
- **Probability Assessment**: Provides likelihood percentages for different conditions
- **Next Steps Guidance**: Offers recommendations for monitoring and follow-up care

### 3. Treatment Plans
- **Personalized Recommendations**: Generate comprehensive treatment plans for diagnosed conditions
- **Multi-faceted Approach**: Includes medications, lifestyle modifications, and follow-up care
- **Evidence-based Guidance**: Provides structured, medical-grade recommendations

### 4. Health Analytics
- **Interactive Dashboards**: Visualize health metrics with dynamic charts
- **Trend Analysis**: Monitor vital signs over time (heart rate, blood pressure, blood glucose)
- **AI-Powered Insights**: Receive personalized health recommendations based on data trends
- **Symptom Tracking**: Track and visualize symptom frequency

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- IBM Watson Machine Learning account
- IBM Granite model access

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd healthai
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   # Copy the template and add your credentials
   cp env_template.txt .env
   ```
   
   Edit `.env` file with your IBM Watson credentials:
   ```
   WATSONX_API_KEY=your_api_key_here
   WATSONX_PROJECT_ID=your_project_id_here
   ```

5. **Run the application**
   ```bash
   streamlit run app.py
   ```

6. **Access the application**
   Open your browser and navigate to `http://localhost:8501`

## 📋 Usage Guide

### Patient Chat
1. Navigate to "Patient Chat" in the sidebar
2. Type your health question in the text input
3. Click "Send" to receive an AI-powered response
4. View conversation history below the input

### Disease Prediction
1. Select "Disease Prediction" from the sidebar
2. Describe your symptoms in detail in the text area
3. Click "Analyze Symptoms" to receive potential diagnoses
4. Review probability assessments and next steps

### Treatment Plans
1. Go to "Treatment Plans" section
2. Enter your diagnosed condition
3. Click "Generate Treatment Plan" for personalized recommendations
4. Review comprehensive treatment guidance

### Health Analytics
1. Access "Health Analytics" dashboard
2. View real-time health metrics and trends
3. Analyze AI-generated insights
4. Monitor symptom frequency and patterns

## 🏗️ Architecture

### Technology Stack
- **Frontend**: Streamlit (Python web framework)
- **AI/ML**: IBM Watson Machine Learning with Granite-13b-instruct-v2
- **Data Visualization**: Plotly
- **Data Processing**: Pandas, NumPy
- **Environment Management**: python-dotenv

### Application Structure
```
healthai/
├── app.py                 # Main application file
├── requirements.txt       # Python dependencies
├── env_template.txt       # Environment variables template
├── README.md             # Project documentation
└── .env                  # Environment variables (create from template)
```

### Key Components
1. **IBM Watson Integration**: Connects to Granite model for AI responses
2. **Session Management**: Maintains chat history and patient data
3. **Data Generation**: Creates realistic sample health data for demonstration
4. **Responsive UI**: Modern, intuitive interface with custom styling
5. **Medical Disclaimers**: Ensures responsible AI usage in healthcare

## 🔧 Configuration

### IBM Watson Setup
1. Create an IBM Cloud account
2. Set up Watson Machine Learning service
3. Access Granite-13b-instruct-v2 model
4. Generate API key and project ID
5. Add credentials to `.env` file

### Customization
- **Styling**: Modify CSS in the `st.markdown()` section of `app.py`
- **AI Responses**: Replace mock responses with actual IBM Granite API calls
- **Data Sources**: Connect to real patient data systems
- **Features**: Extend functionality with additional health metrics

## ⚠️ Important Disclaimers

### Medical Disclaimer
This application is for educational and informational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare providers for medical concerns.

### AI Limitations
- Responses are based on general medical knowledge
- Individual cases may vary significantly
- AI cannot replace professional medical judgment
- Always verify information with healthcare professionals

### Data Privacy
- Sample data is generated for demonstration purposes
- No real patient data is stored or processed
- Implement proper data security measures for production use

## 🚀 Deployment

### Local Development
```bash
streamlit run app.py
```

### Cloud Deployment
1. **Streamlit Cloud**:
   - Connect your GitHub repository
   - Set environment variables in Streamlit Cloud dashboard
   - Deploy automatically

2. **Heroku**:
   - Create `Procfile` with: `web: streamlit run app.py`
   - Set environment variables in Heroku dashboard
   - Deploy using Heroku CLI

3. **AWS/GCP/Azure**:
   - Use containerization with Docker
   - Set up environment variables
   - Deploy to cloud platform

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Refer to IBM Watson documentation

## 🔮 Future Enhancements

- **Real-time Data Integration**: Connect to wearable devices and health apps
- **Advanced Analytics**: Machine learning models for predictive health insights
- **Multi-language Support**: Internationalization for global users
- **Mobile App**: Native mobile application development
- **Telemedicine Integration**: Video consultation capabilities
- **Electronic Health Records**: Secure EHR integration
- **Prescription Management**: Medication tracking and reminders

---

**HealthAI** - Empowering healthcare with intelligent AI assistance 