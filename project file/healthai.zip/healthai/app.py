import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import requests
import json
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
import random

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="HealthAI - Intelligent Healthcare Assistant",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for enhanced styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
        font-weight: bold;
    }
    .feature-card {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 10px;
        border-left: 4px solid #1f77b4;
        margin: 1rem 0;
    }
    .metric-card {
        background-color: #ffffff;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 0.5rem 0;
        color: #000000 !important;
    }
    .chat-message {
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 10px;
        color: #000000;
    }
    .user-message {
        background-color: #e3f2fd;
        margin-left: 2rem;
        color: #000000;
    }
    .ai-message {
        background-color: #f3e5f5;
        margin-right: 2rem;
        color: #000000;
    }
    .warning-box {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        border-radius: 5px;
        padding: 1rem;
        margin: 1rem 0;
        color: #000000;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'patient_data' not in st.session_state:
    st.session_state.patient_data = None

# Import the Watson integration
from watson_integration import init_watson_client, WatsonGraniteClient

# IBM Watson ML Configuration
def init_granite_model():
    """Initialize IBM Granite model connection"""
    try:
        client = init_watson_client()
        if client:
            return client
        else:
            st.warning("IBM Watson not configured. Using demo responses.")
            return None
    except Exception as e:
        st.error(f"Error initializing IBM Watson: {str(e)}")
        return None

# IBM Watson Granite API integration
def get_ai_response(prompt, context=""):
    """Get AI response from IBM Granite model"""
    try:
        # Get Watson client
        watson_client = init_granite_model()
        if not watson_client:
            return get_fallback_response(prompt, context)
        
        # Use the appropriate method based on context
        if context == "chat":
            return watson_client.health_chat_response(prompt)
        elif context == "disease":
            return watson_client.disease_prediction(prompt)
        elif context == "treatment":
            return watson_client.treatment_plan_generation(prompt)
        else:
            return watson_client.health_chat_response(prompt)
            
    except Exception as e:
        st.error(f"Error: {str(e)}")
        # Fallback to mock responses if API fails
        return get_fallback_response(prompt, context)

def get_fallback_response(prompt, context):
    """Fallback responses when IBM Watson is unavailable"""
    responses = {
        "chat": [
            "Based on your symptoms, it sounds like you might be experiencing stress-related tension. I recommend getting adequate rest and staying hydrated. However, if symptoms persist, please consult a healthcare professional.",
            "Your symptoms could indicate several possible conditions. The most common causes include seasonal allergies, mild viral infections, or stress. I'd recommend monitoring your symptoms and seeking medical attention if they worsen.",
            "Thank you for sharing your health concerns. While I can provide general information, it's important to consult with a qualified healthcare provider for personalized medical advice and proper diagnosis."
        ],
        "disease": [
            "Based on the symptoms you've described, the most likely conditions are:\n\n1. **Tension Headache** (70% probability)\n   - Common cause of persistent headaches\n   - Often related to stress or muscle tension\n   - Usually responds to rest and over-the-counter pain relievers\n\n2. **Viral Infection** (20% probability)\n   - Mild fever and fatigue are common symptoms\n   - Usually self-limiting within 7-10 days\n   - Rest and hydration are key\n\n3. **Seasonal Allergies** (10% probability)\n   - Can cause fatigue and mild symptoms\n   - Antihistamines may help\n\n**Next Steps:**\n- Monitor symptoms for 24-48 hours\n- Rest and stay hydrated\n- Seek medical attention if symptoms worsen or persist beyond 3 days"
        ],
        "treatment": [
            "**Personalized Treatment Plan for Your Condition**\n\n**Medications:**\n- Over-the-counter pain relievers (acetaminophen or ibuprofen) as needed\n- Prescription medications may be required based on severity\n\n**Lifestyle Modifications:**\n- Ensure 7-9 hours of quality sleep per night\n- Practice stress management techniques (meditation, deep breathing)\n- Maintain regular exercise routine (30 minutes daily)\n- Stay hydrated (8-10 glasses of water daily)\n- Avoid caffeine and alcohol if they trigger symptoms\n\n**Follow-up Care:**\n- Schedule follow-up appointment in 2 weeks\n- Monitor symptoms daily and keep a symptom diary\n- Contact healthcare provider if symptoms worsen\n\n**Preventive Measures:**\n- Regular health check-ups\n- Balanced diet rich in fruits and vegetables\n- Regular exercise and stress management"
        ]
    }
    
    if context == "chat":
        return random.choice(responses["chat"])
    elif context == "disease":
        return random.choice(responses["disease"])
    elif context == "treatment":
        return random.choice(responses["treatment"])
    else:
        return "I understand your health concern. While I can provide general information, please consult with a healthcare professional for personalized medical advice."

# Generate sample patient data
def generate_patient_data():
    """Generate realistic sample patient health data"""
    dates = pd.date_range(start=datetime.now() - timedelta(days=30), end=datetime.now(), freq='D')
    
    # Generate realistic health metrics
    heart_rate = np.random.normal(72, 8, len(dates))
    heart_rate = np.clip(heart_rate, 60, 100)
    
    systolic = np.random.normal(120, 10, len(dates))
    systolic = np.clip(systolic, 110, 140)
    
    diastolic = np.random.normal(80, 8, len(dates))
    diastolic = np.clip(diastolic, 70, 90)
    
    blood_glucose = np.random.normal(100, 15, len(dates))
    blood_glucose = np.clip(blood_glucose, 80, 140)
    
    # Generate symptoms data
    symptoms = ['Headache', 'Fatigue', 'Dizziness', 'Nausea', 'Chest Pain', 'Shortness of Breath']
    symptom_counts = np.random.randint(1, 10, len(symptoms))
    
    return {
        'dates': dates,
        'heart_rate': heart_rate,
        'systolic': systolic,
        'diastolic': diastolic,
        'blood_glucose': blood_glucose,
        'symptoms': symptoms,
        'symptom_counts': symptom_counts
    }

# Core Functions
def predict_disease(symptoms, patient_data=None):
    """Analyze symptoms for potential diagnoses"""
    prompt = f"Analyze these symptoms for potential medical conditions: {symptoms}"
    return get_ai_response(prompt, "disease")

def generate_treatment_plan(condition, patient_data=None):
    """Create personalized treatment recommendations"""
    prompt = f"Generate a comprehensive treatment plan for: {condition}"
    return get_ai_response(prompt, "treatment")

def answer_patient_query(query, chat_history=None):
    """Process health questions with AI responses"""
    # Pass the raw query directly to allow proper greeting detection
    return get_ai_response(query, "chat")

# UI Components
def display_patient_chat():
    """Display the patient chat interface"""
    st.markdown("## 💬 Patient Chat")
    st.markdown("Ask any health-related questions and receive intelligent responses.")
    
    # Initialize chat input counter
    if 'chat_input_counter' not in st.session_state:
        st.session_state.chat_input_counter = 0
    
    # Chat input with dynamic key to force clearing
    user_input = st.text_input("Ask your health question:", key=f"chat_input_{st.session_state.chat_input_counter}")
    
    if st.button("Send", key="send_chat"):
        if user_input:
            # Add user message to history
            st.session_state.chat_history.append({
                'role': 'user',
                'message': user_input,
                'timestamp': datetime.now()
            })
            
            # Get AI response
            ai_response = answer_patient_query(user_input, st.session_state.chat_history)
            
            # Add AI response to history
            st.session_state.chat_history.append({
                'role': 'ai',
                'message': ai_response,
                'timestamp': datetime.now()
            })
            
            # Increment counter to force new input field
            st.session_state.chat_input_counter += 1
            st.rerun()
    
    # Display chat history
    if st.session_state.chat_history:
        st.markdown("### Chat History")
        for message in st.session_state.chat_history:
            if message['role'] == 'user':
                st.markdown(f"""
                <div class="chat-message user-message">
                    <strong>You:</strong> {message['message']}
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="chat-message ai-message">
                    <strong>HealthAI:</strong> {message['message']}
                </div>
                """, unsafe_allow_html=True)
    
    # Medical disclaimer
    st.markdown("""
    <div class="warning-box">
        <strong>Medical Disclaimer:</strong> This AI assistant provides general health information only. 
        It is not a substitute for professional medical advice, diagnosis, or treatment. 
        Always consult with a qualified healthcare provider for medical concerns.
    </div>
    """, unsafe_allow_html=True)

def display_disease_prediction():
    """Display the disease prediction interface"""
    st.markdown("## 🔍 Disease Prediction")
    st.markdown("Enter your symptoms to receive potential condition analysis.")
    
    # Symptom input
    symptoms = st.text_area(
        "Describe your symptoms in detail:",
        placeholder="e.g., persistent headache for 3 days, fatigue, mild fever around 100.4°F, loss of appetite...",
        height=150
    )
    
    if st.button("Analyze Symptoms", key="analyze_symptoms"):
        if symptoms:
            with st.spinner("Analyzing symptoms..."):
                prediction = predict_disease(symptoms)
                st.markdown("### Analysis Results")
                st.markdown(prediction)
        else:
            st.warning("Please enter your symptoms to receive an analysis.")
    
    # Medical disclaimer
    st.markdown("""
    <div class="warning-box">
        <strong>Important:</strong> This analysis is for informational purposes only and should not replace 
        professional medical diagnosis. Always consult with a healthcare provider for proper evaluation.
    </div>
    """, unsafe_allow_html=True)

def display_treatment_plans():
    """Display the treatment plan generator"""
    st.markdown("## 💊 Treatment Plans")
    st.markdown("Get personalized treatment recommendations for your condition.")
    
    # Condition input
    condition = st.text_input(
        "Enter your diagnosed condition:",
        placeholder="e.g., Hypertension, Diabetes Type 2, Migraine..."
    )
    
    if st.button("Generate Treatment Plan", key="generate_plan"):
        if condition:
            with st.spinner("Generating personalized treatment plan..."):
                treatment_plan = generate_treatment_plan(condition)
                st.markdown("### Your Treatment Plan")
                st.markdown(treatment_plan)
        else:
            st.warning("Please enter your condition to generate a treatment plan.")
    
    # Medical disclaimer
    st.markdown("""
    <div class="warning-box">
        <strong>Medical Disclaimer:</strong> Treatment plans are for informational purposes only. 
        Always follow your healthcare provider's prescribed treatment regimen and consult them 
        before making any changes to your medical care.
    </div>
    """, unsafe_allow_html=True)

def display_health_analytics():
    """Display the health analytics dashboard"""
    st.markdown("## 📊 Health Analytics")
    st.markdown("Monitor your health metrics and trends with AI-powered insights.")
    
    # Generate or load patient data
    if st.session_state.patient_data is None:
        st.session_state.patient_data = generate_patient_data()
    
    data = st.session_state.patient_data
    
    # Create metrics summary
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        current_hr = data['heart_rate'][-1]
        hr_trend = "↗️" if current_hr > np.mean(data['heart_rate']) else "↘️"
        st.metric("Heart Rate", f"{current_hr:.0f} bpm", delta=f"{hr_trend}")
    
    with col2:
        current_sys = data['systolic'][-1]
        sys_trend = "↗️" if current_sys > np.mean(data['systolic']) else "↘️"
        st.metric("Systolic BP", f"{current_sys:.0f} mmHg", delta=f"{sys_trend}")
    
    with col3:
        current_dia = data['diastolic'][-1]
        dia_trend = "↗️" if current_dia > np.mean(data['diastolic']) else "↘️"
        st.metric("Diastolic BP", f"{current_dia:.0f} mmHg", delta=f"{dia_trend}")
    
    with col4:
        current_bg = data['blood_glucose'][-1]
        bg_trend = "↗️" if current_bg > np.mean(data['blood_glucose']) else "↘️"
        st.metric("Blood Glucose", f"{current_bg:.0f} mg/dL", delta=f"{bg_trend}")
    
    # Create charts
    col1, col2 = st.columns(2)
    
    with col1:
        # Heart rate trend
        fig_hr = px.line(
            x=data['dates'], 
            y=data['heart_rate'],
            title="Heart Rate Trend (30 Days)",
            labels={'x': 'Date', 'y': 'Heart Rate (bpm)'}
        )
        fig_hr.add_hline(y=72, line_dash="dash", line_color="red", annotation_text="Normal Range")
        st.plotly_chart(fig_hr, use_container_width=True)
        
        # Blood pressure trend
        fig_bp = go.Figure()
        fig_bp.add_trace(go.Scatter(x=data['dates'], y=data['systolic'], name='Systolic', line=dict(color='red')))
        fig_bp.add_trace(go.Scatter(x=data['dates'], y=data['diastolic'], name='Diastolic', line=dict(color='blue')))
        fig_bp.update_layout(title="Blood Pressure Trend (30 Days)", xaxis_title="Date", yaxis_title="mmHg")
        st.plotly_chart(fig_bp, use_container_width=True)
    
    with col2:
        # Blood glucose trend
        fig_bg = px.line(
            x=data['dates'], 
            y=data['blood_glucose'],
            title="Blood Glucose Trend (30 Days)",
            labels={'x': 'Date', 'y': 'Blood Glucose (mg/dL)'}
        )
        fig_bg.add_hline(y=100, line_dash="dash", line_color="orange", annotation_text="Normal Range")
        st.plotly_chart(fig_bg, use_container_width=True)
        
        # Symptoms frequency
        fig_symptoms = px.pie(
            values=data['symptom_counts'],
            names=data['symptoms'],
            title="Symptom Frequency"
        )
        st.plotly_chart(fig_symptoms, use_container_width=True)
    
    # AI Insights
    st.markdown("### 🤖 AI-Powered Health Insights")
    
    # Generate insights based on data
    hr_avg = np.mean(data['heart_rate'])
    bp_avg = np.mean(data['systolic'])
    bg_avg = np.mean(data['blood_glucose'])
    
    insights = []
    
    # Generate insights based on data
    hr_avg = np.mean(data['heart_rate'])
    bp_avg = np.mean(data['systolic'])
    bg_avg = np.mean(data['blood_glucose'])
    
    insights = []
    
    if hr_avg > 75:
        insights.append("⚠️ Your average heart rate is slightly elevated. Consider stress management techniques and regular exercise.")
    else:
        insights.append("✅ Your heart rate is within normal range. Keep up the good work!")
    
    if bp_avg > 125:
        insights.append("⚠️ Your systolic blood pressure is elevated. Monitor your salt intake and consider lifestyle modifications.")
    else:
        insights.append("✅ Your blood pressure is well-controlled. Continue your current healthy habits.")
    
    if bg_avg > 110:
        insights.append("⚠️ Your blood glucose levels are elevated. Focus on balanced meals and regular physical activity.")
    else:
        insights.append("✅ Your blood glucose is well-managed. Maintain your current dietary habits.")
    
    for insight in insights:
        st.markdown(f"<div class='metric-card'>{insight}</div>", unsafe_allow_html=True)

# Sidebar
def sidebar():
    """Create the sidebar with patient profile and navigation"""
    st.sidebar.markdown("## 🏥 HealthAI")
    st.sidebar.markdown("Intelligent Healthcare Assistant")
    
    # Patient Profile
    st.sidebar.markdown("### 👤 Patient Profile")
    
    # Initialize patient data in session state if not exists
    if 'patient_profile' not in st.session_state:
        st.session_state.patient_profile = {
            "name": "",
            "age": None,
            "gender": "Male",
            "blood_type": "A+"
        }
    
    # Patient Profile Input Fields
    st.session_state.patient_profile["name"] = st.sidebar.text_input(
        "Name", 
        value=st.session_state.patient_profile["name"],
        placeholder="Enter patient name",
        key="profile_name"
    )
    
    col1, col2 = st.sidebar.columns(2)
    with col1:
        age_input = st.text_input(
            "Age", 
            value=st.session_state.patient_profile["age"] if st.session_state.patient_profile["age"] else "",
            placeholder="Enter age",
            key="profile_age"
        )
        # Convert to integer if valid, otherwise keep as string
        if age_input.isdigit() and 0 <= int(age_input) <= 120:
            st.session_state.patient_profile["age"] = int(age_input)
        else:
            st.session_state.patient_profile["age"] = age_input
    with col2:
        st.session_state.patient_profile["gender"] = st.selectbox(
            "Gender",
            options=["Male", "Female", "Other"],
            index=["Male", "Female", "Other"].index(st.session_state.patient_profile["gender"]),
            key="profile_gender"
        )
    
    st.session_state.patient_profile["blood_type"] = st.sidebar.selectbox(
        "Blood Type",
        options=["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
        index=["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].index(st.session_state.patient_profile["blood_type"]),
        key="profile_blood_type"
    )
    
    # Enter Button
    if st.sidebar.button("Enter", key="enter_profile"):
        if st.session_state.patient_profile["name"]:
            st.session_state.profile_entered = True
            st.sidebar.success("✅ Patient profile entered successfully!")
        else:
            st.sidebar.warning("⚠️ Please enter a patient name")
    
    # Check if profile has been entered
    if 'profile_entered' not in st.session_state:
        st.session_state.profile_entered = False
    
    st.sidebar.markdown("---")
    
    # Feature Selection
    st.sidebar.markdown("### 🎯 Features")
    
    if st.session_state.profile_entered:
        # Navigation - enabled when profile is entered
        page = st.sidebar.selectbox(
            "Choose a feature:",
            ["Patient Chat", "Disease Prediction", "Treatment Plans", "Health Analytics"]
        )
    else:
        # Show disabled state
        st.sidebar.info("👤 Please enter patient profile to access features")
        page = "Patient Chat"  # Default page
    
    return page

# Main Application
def main():
    """Main application function"""
    st.markdown('<h1 class="main-header">🏥 HealthAI</h1>', unsafe_allow_html=True)
    st.markdown('<p style="text-align: center; font-size: 1.2rem; color: #666;">Intelligent Healthcare Assistant Using IBM Granite</p>', unsafe_allow_html=True)
    
    # Initialize IBM Watson (this will be done per request)
    
    # Sidebar
    selected_page = sidebar()
    
    # Main content area
    if not st.session_state.profile_entered:
        st.markdown("## 👤 Welcome to HealthAI")
        st.markdown("Please enter your patient profile in the sidebar to access all features.")
        st.markdown("""
        <div style="text-align: center; padding: 2rem; background-color: #f8f9fa; border-radius: 10px; margin: 2rem 0; color: #000000;">
            <h3 style="color: #000000;">🏥 HealthAI Features</h3>
            <p style="color: #000000;">Once you enter your patient profile, you'll have access to:</p>
            <ul style="text-align: left; display: inline-block; color: #000000;">
                <li style="color: #000000;">💬 <strong>Patient Chat</strong> - Ask health questions</li>
                <li style="color: #000000;">🔍 <strong>Disease Prediction</strong> - Analyze symptoms</li>
                <li style="color: #000000;">💊 <strong>Treatment Plans</strong> - Get treatment recommendations</li>
                <li style="color: #000000;">📊 <strong>Health Analytics</strong> - Monitor health metrics</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    else:
        if selected_page == "Patient Chat":
            display_patient_chat()
        elif selected_page == "Disease Prediction":
            display_disease_prediction()
        elif selected_page == "Treatment Plans":
            display_treatment_plans()
        elif selected_page == "Health Analytics":
            display_health_analytics()
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; font-size: 0.9rem;">
        <p>HealthAI - Powered by IBM Watson Machine Learning and Granite AI</p>
        <p>This application is for educational and informational purposes only.</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main() 