"""
Configuration file for HealthAI application
Contains application settings, constants, and configuration parameters
"""

import os
from typing import Dict, List

# Application Configuration
APP_CONFIG = {
    "name": "HealthAI",
    "version": "1.0.0",
    "description": "Intelligent Healthcare Assistant Using IBM Granite",
    "author": "HealthAI Team",
    "page_title": "HealthAI - Intelligent Healthcare Assistant",
    "page_icon": "🏥",
    "layout": "wide",
    "initial_sidebar_state": "expanded"
}

# IBM Watson Configuration
WATSON_CONFIG = {
    "base_url": "https://us-south.ml.cloud.ibm.com",
    "model_id": "ibm-granite-13b-instruct-v2",
    "timeout": 30,
    "max_tokens": 1000,
    "temperature": 0.7,
    "top_p": 0.9,
    "repetition_penalty": 1.1
}

# Health Metrics Configuration
HEALTH_METRICS = {
    "heart_rate": {
        "normal_min": 60,
        "normal_max": 100,
        "unit": "bpm",
        "description": "Heart Rate"
    },
    "systolic_bp": {
        "normal_min": 90,
        "normal_max": 140,
        "unit": "mmHg",
        "description": "Systolic Blood Pressure"
    },
    "diastolic_bp": {
        "normal_min": 60,
        "normal_max": 90,
        "unit": "mmHg",
        "description": "Diastolic Blood Pressure"
    },
    "blood_glucose": {
        "normal_min": 70,
        "normal_max": 140,
        "unit": "mg/dL",
        "description": "Blood Glucose"
    },
    "temperature": {
        "normal_min": 97,
        "normal_max": 99,
        "unit": "°F",
        "description": "Body Temperature"
    },
    "oxygen_saturation": {
        "normal_min": 95,
        "normal_max": 100,
        "unit": "%",
        "description": "Oxygen Saturation"
    }
}

# UI Configuration
UI_CONFIG = {
    "colors": {
        "primary": "#1f77b4",
        "secondary": "#ff7f0e",
        "success": "#2ca02c",
        "warning": "#d62728",
        "info": "#17a2b8",
        "light": "#f8f9fa",
        "dark": "#343a40"
    },
    "chart_colors": [
        "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", 
        "#9467bd", "#8c564b", "#e377c2", "#7f7f7f"
    ],
    "css_styles": {
        "main_header": """
            font-size: 2.5rem;
            color: #1f77b4;
            text-align: center;
            margin-bottom: 2rem;
            font-weight: bold;
        """,
        "feature_card": """
            background-color: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid #1f77b4;
            margin: 1rem 0;
        """,
        "metric_card": """
            background-color: #ffffff;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 0.5rem 0;
        """,
        "chat_message": """
            padding: 1rem;
            margin: 0.5rem 0;
            border-radius: 10px;
        """,
        "user_message": """
            background-color: #e3f2fd;
            margin-left: 2rem;
        """,
        "ai_message": """
            background-color: #f3e5f5;
            margin-right: 2rem;
        """,
        "warning_box": """
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 5px;
            padding: 1rem;
            margin: 1rem 0;
        """
    }
}

# Feature Configuration
FEATURES = {
    "patient_chat": {
        "name": "Patient Chat",
        "description": "Ask health questions and receive AI-powered responses",
        "icon": "💬",
        "enabled": True
    },
    "disease_prediction": {
        "name": "Disease Prediction",
        "description": "Analyze symptoms for potential conditions",
        "icon": "🔍",
        "enabled": True
    },
    "treatment_plans": {
        "name": "Treatment Plans",
        "description": "Generate personalized treatment recommendations",
        "icon": "💊",
        "enabled": True
    },
    "health_analytics": {
        "name": "Health Analytics",
        "description": "Monitor health metrics and trends",
        "icon": "📊",
        "enabled": True
    }
}

# Sample Data Configuration
SAMPLE_DATA_CONFIG = {
    "default_days": 30,
    "update_frequency": "daily",
    "symptoms": [
        "Headache", "Fatigue", "Dizziness", "Nausea", 
        "Chest Pain", "Shortness of Breath", "Fever", "Cough"
    ],
    "patient_info": {
        "name": "John Doe",
        "age": 35,
        "gender": "Male",
        "blood_type": "O+",
        "height_cm": 175,
        "weight_kg": 70.2,
        "last_visit": "2024-01-15",
        "primary_care_physician": "Dr. Sarah Johnson",
        "allergies": ["Penicillin", "Shellfish"],
        "medications": ["Lisinopril 10mg daily", "Metformin 500mg twice daily"],
        "conditions": ["Hypertension", "Type 2 Diabetes"]
    }
}

# Medical Disclaimer Configuration
DISCLAIMERS = {
    "general": """
        <div class="warning-box">
            <strong>Medical Disclaimer:</strong> This AI assistant provides general health information only. 
            It is not a substitute for professional medical advice, diagnosis, or treatment. 
            Always consult with a qualified healthcare provider for medical concerns.
        </div>
    """,
    "disease_prediction": """
        <div class="warning-box">
            <strong>Important:</strong> This analysis is for informational purposes only and should not replace 
            professional medical diagnosis. Always consult with a healthcare provider for proper evaluation.
        </div>
    """,
    "treatment_plans": """
        <div class="warning-box">
            <strong>Medical Disclaimer:</strong> Treatment plans are for informational purposes only. 
            Always follow your healthcare provider's prescribed treatment regimen and consult them 
            before making any changes to your medical care.
        </div>
    """,
    "chat": """
        <div class="warning-box">
            <strong>Medical Disclaimer:</strong> This AI assistant provides general health information only. 
            It is not a substitute for professional medical advice, diagnosis, or treatment. 
            Always consult with a qualified healthcare provider for medical concerns.
        </div>
    """
}

# Prompt Templates
PROMPT_TEMPLATES = {
    "chat": """
        You are a helpful healthcare assistant. Answer the following health question professionally and accurately.
        Always include appropriate medical disclaimers and recommend consulting healthcare professionals when appropriate.
        
        Context: {context}
        Question: {query}
        
        Provide a clear, informative response:
    """,
    "disease_prediction": """
        You are a medical AI assistant. Analyze the following symptoms and provide potential diagnoses with probability assessments.
        Always emphasize that this is for informational purposes only and recommend professional medical consultation.
        
        {patient_info}
        Symptoms: {symptoms}
        
        Provide analysis in this format:
        1. Most likely conditions with probability percentages
        2. Brief explanation of each condition
        3. Recommended next steps
        4. Medical disclaimer
    """,
    "treatment_plan": """
        You are a medical AI assistant. Generate a comprehensive treatment plan for the following condition.
        Include medications, lifestyle modifications, follow-up care, and preventive measures.
        Always emphasize consulting healthcare providers for personalized treatment.
        
        {patient_info}
        Condition: {condition}
        
        Provide treatment plan in this format:
        1. Medications (with disclaimers about prescription requirements)
        2. Lifestyle Modifications
        3. Follow-up Care
        4. Preventive Measures
        5. Medical disclaimer
    """,
    "health_insights": """
        You are a medical AI assistant. Analyze the following health data and provide insights and recommendations.
        Focus on trends, potential concerns, and actionable advice.
        
        Health Data: {health_data}
        
        Provide insights covering:
        1. Key observations about health trends
        2. Potential health concerns
        3. Recommendations for improvement
        4. When to seek medical attention
    """
}

# Error Messages
ERROR_MESSAGES = {
    "watson_connection": "Unable to connect to IBM Watson. Please check your credentials and internet connection.",
    "missing_credentials": "IBM Watson credentials not found. Please set WATSONX_API_KEY and WATSONX_PROJECT_ID in your .env file.",
    "invalid_input": "Please provide valid input for this feature.",
    "data_generation": "Error generating sample data. Please try again.",
    "chart_creation": "Error creating visualization. Please check your data.",
    "api_timeout": "Request timed out. Please try again later.",
    "general_error": "An error occurred. Please try again or contact support."
}

# Success Messages
SUCCESS_MESSAGES = {
    "chat_sent": "Message sent successfully!",
    "analysis_complete": "Symptom analysis completed!",
    "plan_generated": "Treatment plan generated successfully!",
    "data_updated": "Health data updated successfully!",
    "settings_saved": "Settings saved successfully!"
}

# Validation Rules
VALIDATION_RULES = {
    "symptoms": {
        "min_length": 10,
        "max_length": 1000,
        "required": True
    },
    "condition": {
        "min_length": 3,
        "max_length": 200,
        "required": True
    },
    "chat_message": {
        "min_length": 1,
        "max_length": 500,
        "required": True
    }
}

def get_config() -> Dict:
    """Get complete application configuration"""
    return {
        "app": APP_CONFIG,
        "watson": WATSON_CONFIG,
        "health_metrics": HEALTH_METRICS,
        "ui": UI_CONFIG,
        "features": FEATURES,
        "sample_data": SAMPLE_DATA_CONFIG,
        "disclaimers": DISCLAIMERS,
        "prompts": PROMPT_TEMPLATES,
        "errors": ERROR_MESSAGES,
        "success": SUCCESS_MESSAGES,
        "validation": VALIDATION_RULES
    }

def get_feature_config(feature_name: str) -> Dict:
    """Get configuration for a specific feature"""
    return FEATURES.get(feature_name, {})

def is_feature_enabled(feature_name: str) -> bool:
    """Check if a feature is enabled"""
    feature = get_feature_config(feature_name)
    return feature.get("enabled", False)

def get_health_metric_config(metric_name: str) -> Dict:
    """Get configuration for a specific health metric"""
    return HEALTH_METRICS.get(metric_name, {})

def get_disclaimer(disclaimer_type: str) -> str:
    """Get disclaimer text for a specific type"""
    return DISCLAIMERS.get(disclaimer_type, DISCLAIMERS["general"])

def get_prompt_template(template_name: str) -> str:
    """Get prompt template for a specific type"""
    return PROMPT_TEMPLATES.get(template_name, "")

def get_error_message(error_type: str) -> str:
    """Get error message for a specific type"""
    return ERROR_MESSAGES.get(error_type, ERROR_MESSAGES["general_error"])

def get_success_message(success_type: str) -> str:
    """Get success message for a specific type"""
    return SUCCESS_MESSAGES.get(success_type, "Operation completed successfully!")

# Environment-specific configurations
def get_environment_config() -> Dict:
    """Get environment-specific configuration"""
    env = os.getenv("ENVIRONMENT", "development")
    
    if env == "production":
        return {
            "debug": False,
            "log_level": "INFO",
            "cache_enabled": True,
            "rate_limiting": True
        }
    else:
        return {
            "debug": True,
            "log_level": "DEBUG",
            "cache_enabled": False,
            "rate_limiting": False
        } 