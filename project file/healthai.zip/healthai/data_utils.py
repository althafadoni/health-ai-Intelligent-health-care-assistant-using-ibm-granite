"""
Data Utilities for HealthAI
Handles patient data generation, management, and analytics
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

class PatientDataManager:
    """Manages patient health data and analytics"""
    
    def __init__(self):
        self.data = None
        self.patient_info = None
    
    def generate_sample_patient_data(self, days: int = 30) -> Dict:
        """
        Generate realistic sample patient health data
        
        Args:
            days: Number of days of data to generate
            
        Returns:
            Dictionary containing health metrics and patient info
        """
        dates = pd.date_range(start=datetime.now() - timedelta(days=days), end=datetime.now(), freq='D')
        
        # Generate realistic health metrics with some trends
        np.random.seed(42)  # For reproducible results
        
        # Heart rate: normal range 60-100 bpm
        heart_rate_trend = np.linspace(75, 78, len(dates))  # Slight upward trend
        heart_rate = heart_rate_trend + np.random.normal(0, 5, len(dates))
        heart_rate = np.clip(heart_rate, 60, 100)
        
        # Blood pressure: normal systolic 90-140, diastolic 60-90
        systolic_trend = np.linspace(125, 128, len(dates))  # Slight upward trend
        systolic = systolic_trend + np.random.normal(0, 8, len(dates))
        systolic = np.clip(systolic, 110, 140)
        
        diastolic_trend = np.linspace(82, 85, len(dates))  # Slight upward trend
        diastolic = diastolic_trend + np.random.normal(0, 6, len(dates))
        diastolic = np.clip(diastolic, 70, 90)
        
        # Blood glucose: normal range 70-140 mg/dL
        glucose_trend = np.linspace(105, 108, len(dates))  # Slight upward trend
        blood_glucose = glucose_trend + np.random.normal(0, 12, len(dates))
        blood_glucose = np.clip(blood_glucose, 80, 140)
        
        # Weight: slight variation
        weight_trend = np.linspace(70, 70.5, len(dates))  # Very slight increase
        weight = weight_trend + np.random.normal(0, 0.3, len(dates))
        
        # Temperature: normal range 97-99°F
        temperature = np.random.normal(98.6, 0.5, len(dates))
        temperature = np.clip(temperature, 97, 99)
        
        # Oxygen saturation: normal range 95-100%
        oxygen_sat = np.random.normal(98, 1, len(dates))
        oxygen_sat = np.clip(oxygen_sat, 95, 100)
        
        # Generate symptoms data
        symptoms = ['Headache', 'Fatigue', 'Dizziness', 'Nausea', 'Chest Pain', 'Shortness of Breath', 'Fever', 'Cough']
        symptom_counts = np.random.randint(1, 15, len(symptoms))
        
        # Create DataFrame
        df = pd.DataFrame({
            'date': dates,
            'heart_rate': heart_rate,
            'systolic_bp': systolic,
            'diastolic_bp': diastolic,
            'blood_glucose': blood_glucose,
            'weight_kg': weight,
            'temperature_f': temperature,
            'oxygen_saturation': oxygen_sat
        })
        
        return {
            'dataframe': df,
            'dates': dates,
            'heart_rate': heart_rate,
            'systolic': systolic,
            'diastolic': diastolic,
            'blood_glucose': blood_glucose,
            'weight': weight,
            'temperature': temperature,
            'oxygen_saturation': oxygen_sat,
            'symptoms': symptoms,
            'symptom_counts': symptom_counts
        }
    
    def get_patient_info(self) -> Dict:
        """Get sample patient information"""
        return {
            "name": "John Doe",
            "age": 35,
            "gender": "Male",
            "blood_type": "O+",
            "height_cm": 175,
            "weight_kg": 70.2,
            "last_visit": "2024-01-15",
            "primary_care_physician": "Dr. Sarah Johnson",
            "allergies": ["Penicillin", "Shellfish"],
            "medications": ["Lisinopril 10mg daily", "Metformin 500mg twice daily"],
            "conditions": ["Hypertension", "Type 2 Diabetes"]
        }
    
    def calculate_health_metrics(self, data: Dict) -> Dict:
        """
        Calculate summary health metrics from patient data
        
        Args:
            data: Patient health data dictionary
            
        Returns:
            Dictionary with calculated metrics
        """
        df = data['dataframe']
        
        metrics = {
            'heart_rate': {
                'current': df['heart_rate'].iloc[-1],
                'average': df['heart_rate'].mean(),
                'min': df['heart_rate'].min(),
                'max': df['heart_rate'].max(),
                'trend': 'increasing' if df['heart_rate'].iloc[-1] > df['heart_rate'].mean() else 'decreasing',
                'status': 'normal' if 60 <= df['heart_rate'].iloc[-1] <= 100 else 'abnormal'
            },
            'blood_pressure': {
                'systolic_current': df['systolic_bp'].iloc[-1],
                'diastolic_current': df['diastolic_bp'].iloc[-1],
                'systolic_avg': df['systolic_bp'].mean(),
                'diastolic_avg': df['diastolic_bp'].mean(),
                'status': 'normal' if (90 <= df['systolic_bp'].iloc[-1] <= 140 and 
                                     60 <= df['diastolic_bp'].iloc[-1] <= 90) else 'abnormal'
            },
            'blood_glucose': {
                'current': df['blood_glucose'].iloc[-1],
                'average': df['blood_glucose'].mean(),
                'min': df['blood_glucose'].min(),
                'max': df['blood_glucose'].max(),
                'trend': 'increasing' if df['blood_glucose'].iloc[-1] > df['blood_glucose'].mean() else 'decreasing',
                'status': 'normal' if 70 <= df['blood_glucose'].iloc[-1] <= 140 else 'abnormal'
            },
            'weight': {
                'current': df['weight_kg'].iloc[-1],
                'change_30d': df['weight_kg'].iloc[-1] - df['weight_kg'].iloc[0],
                'trend': 'increasing' if df['weight_kg'].iloc[-1] > df['weight_kg'].iloc[0] else 'decreasing'
            },
            'temperature': {
                'current': df['temperature_f'].iloc[-1],
                'average': df['temperature_f'].mean(),
                'status': 'normal' if 97 <= df['temperature_f'].iloc[-1] <= 99 else 'abnormal'
            },
            'oxygen_saturation': {
                'current': df['oxygen_saturation'].iloc[-1],
                'average': df['oxygen_saturation'].mean(),
                'status': 'normal' if df['oxygen_saturation'].iloc[-1] >= 95 else 'abnormal'
            }
        }
        
        return metrics

class HealthVisualizer:
    """Creates health data visualizations"""
    
    @staticmethod
    def create_heart_rate_chart(data: Dict) -> go.Figure:
        """Create heart rate trend chart"""
        fig = px.line(
            x=data['dates'], 
            y=data['heart_rate'],
            title="Heart Rate Trend (30 Days)",
            labels={'x': 'Date', 'y': 'Heart Rate (bpm)'},
            line_color='#1f77b4'
        )
        
        # Add normal range lines
        fig.add_hline(y=60, line_dash="dash", line_color="green", 
                     annotation_text="Normal Min (60 bpm)")
        fig.add_hline(y=100, line_dash="dash", line_color="red", 
                     annotation_text="Normal Max (100 bpm)")
        
        fig.update_layout(
            plot_bgcolor='white',
            paper_bgcolor='white',
            font=dict(size=12)
        )
        
        return fig
    
    @staticmethod
    def create_blood_pressure_chart(data: Dict) -> go.Figure:
        """Create blood pressure trend chart"""
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=data['dates'], 
            y=data['systolic'], 
            name='Systolic', 
            line=dict(color='red', width=2)
        ))
        fig.add_trace(go.Scatter(
            x=data['dates'], 
            y=data['diastolic'], 
            name='Diastolic', 
            line=dict(color='blue', width=2)
        ))
        
        # Add normal range areas
        fig.add_hrect(y0=90, y1=140, fillcolor="lightgreen", opacity=0.2, 
                     annotation_text="Normal Systolic Range")
        fig.add_hrect(y0=60, y1=90, fillcolor="lightblue", opacity=0.2, 
                     annotation_text="Normal Diastolic Range")
        
        fig.update_layout(
            title="Blood Pressure Trend (30 Days)",
            xaxis_title="Date",
            yaxis_title="mmHg",
            plot_bgcolor='white',
            paper_bgcolor='white',
            font=dict(size=12)
        )
        
        return fig
    
    @staticmethod
    def create_blood_glucose_chart(data: Dict) -> go.Figure:
        """Create blood glucose trend chart"""
        fig = px.line(
            x=data['dates'], 
            y=data['blood_glucose'],
            title="Blood Glucose Trend (30 Days)",
            labels={'x': 'Date', 'y': 'Blood Glucose (mg/dL)'},
            line_color='#ff7f0e'
        )
        
        # Add normal range lines
        fig.add_hline(y=70, line_dash="dash", line_color="green", 
                     annotation_text="Normal Min (70 mg/dL)")
        fig.add_hline(y=140, line_dash="dash", line_color="red", 
                     annotation_text="Normal Max (140 mg/dL)")
        fig.add_hline(y=100, line_dash="dot", line_color="orange", 
                     annotation_text="Target (100 mg/dL)")
        
        fig.update_layout(
            plot_bgcolor='white',
            paper_bgcolor='white',
            font=dict(size=12)
        )
        
        return fig
    
    @staticmethod
    def create_symptoms_chart(symptoms: List[str], counts: List[int]) -> go.Figure:
        """Create symptoms frequency pie chart"""
        fig = px.pie(
            values=counts,
            names=symptoms,
            title="Symptom Frequency (Last 30 Days)",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        
        fig.update_layout(
            plot_bgcolor='white',
            paper_bgcolor='white',
            font=dict(size=12)
        )
        
        return fig
    
    @staticmethod
    def create_comprehensive_dashboard(data: Dict) -> go.Figure:
        """Create a comprehensive health dashboard"""
        # Create subplots
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Heart Rate', 'Blood Pressure', 'Blood Glucose', 'Symptoms'),
            specs=[[{"secondary_y": False}, {"secondary_y": False}],
                   [{"secondary_y": False}, {"type": "pie"}]]
        )
        
        # Heart rate
        fig.add_trace(
            go.Scatter(x=data['dates'], y=data['heart_rate'], name='Heart Rate'),
            row=1, col=1
        )
        
        # Blood pressure
        fig.add_trace(
            go.Scatter(x=data['dates'], y=data['systolic'], name='Systolic'),
            row=1, col=2
        )
        fig.add_trace(
            go.Scatter(x=data['dates'], y=data['diastolic'], name='Diastolic'),
            row=1, col=2
        )
        
        # Blood glucose
        fig.add_trace(
            go.Scatter(x=data['dates'], y=data['blood_glucose'], name='Blood Glucose'),
            row=2, col=1
        )
        
        # Symptoms pie chart
        fig.add_trace(
            go.Pie(labels=data['symptoms'], values=data['symptom_counts']),
            row=2, col=2
        )
        
        fig.update_layout(
            height=800,
            title_text="Health Analytics Dashboard",
            showlegend=True,
            plot_bgcolor='white',
            paper_bgcolor='white'
        )
        
        return fig

class HealthAnalyzer:
    """Analyzes health data and provides insights"""
    
    @staticmethod
    def analyze_trends(data: Dict) -> List[str]:
        """
        Analyze health data trends and provide insights
        
        Args:
            data: Patient health data
            
        Returns:
            List of insight messages
        """
        insights = []
        
        # Heart rate analysis
        hr_current = data['heart_rate'][-1]
        hr_avg = np.mean(data['heart_rate'])
        hr_trend = np.polyfit(range(len(data['heart_rate'])), data['heart_rate'], 1)[0]
        
        if hr_trend > 0.5:
            insights.append("⚠️ Your heart rate shows an upward trend. Consider stress management and regular exercise.")
        elif hr_current > 85:
            insights.append("⚠️ Your current heart rate is elevated. Monitor for stress or other triggers.")
        else:
            insights.append("✅ Your heart rate is within normal range and stable.")
        
        # Blood pressure analysis
        bp_sys_current = data['systolic'][-1]
        bp_dia_current = data['diastolic'][-1]
        
        if bp_sys_current > 130 or bp_dia_current > 85:
            insights.append("⚠️ Your blood pressure is elevated. Consider lifestyle modifications and consult your doctor.")
        else:
            insights.append("✅ Your blood pressure is well-controlled.")
        
        # Blood glucose analysis
        bg_current = data['blood_glucose'][-1]
        bg_avg = np.mean(data['blood_glucose'])
        
        if bg_current > 120:
            insights.append("⚠️ Your blood glucose is elevated. Focus on balanced meals and regular physical activity.")
        elif bg_avg > 110:
            insights.append("⚠️ Your average blood glucose is trending high. Monitor your diet and exercise routine.")
        else:
            insights.append("✅ Your blood glucose is well-managed.")
        
        # Weight analysis
        weight_change = data['weight'][-1] - data['weight'][0]
        if abs(weight_change) > 2:
            if weight_change > 0:
                insights.append("📈 You've gained weight recently. Consider reviewing your diet and exercise habits.")
            else:
                insights.append("📉 You've lost weight recently. Ensure this is intentional and healthy.")
        
        return insights
    
    @staticmethod
    def generate_health_summary(metrics: Dict) -> str:
        """
        Generate a health summary based on calculated metrics
        
        Args:
            metrics: Calculated health metrics
            
        Returns:
            Health summary text
        """
        summary_parts = []
        
        # Overall health status
        abnormal_count = sum([
            1 for metric in [metrics['heart_rate'], metrics['blood_pressure'], 
                           metrics['blood_glucose'], metrics['temperature'], 
                           metrics['oxygen_saturation']] 
            if metric.get('status') == 'abnormal'
        ])
        
        if abnormal_count == 0:
            summary_parts.append("🎉 Excellent! All your vital signs are within normal ranges.")
        elif abnormal_count <= 2:
            summary_parts.append("⚠️ Some of your vital signs are outside normal ranges. Monitor closely.")
        else:
            summary_parts.append("🚨 Multiple vital signs are abnormal. Consider consulting your healthcare provider.")
        
        # Specific recommendations
        if metrics['heart_rate']['status'] == 'abnormal':
            summary_parts.append("• Heart rate: Consider stress management and regular exercise")
        
        if metrics['blood_pressure']['status'] == 'abnormal':
            summary_parts.append("• Blood pressure: Monitor salt intake and consider lifestyle changes")
        
        if metrics['blood_glucose']['status'] == 'abnormal':
            summary_parts.append("• Blood glucose: Focus on balanced meals and regular physical activity")
        
        return "\n".join(summary_parts)

# Example usage
if __name__ == "__main__":
    # Test data generation
    data_manager = PatientDataManager()
    sample_data = data_manager.generate_sample_patient_data()
    
    # Test metrics calculation
    metrics = data_manager.calculate_health_metrics(sample_data)
    print("Health Metrics:", metrics)
    
    # Test trend analysis
    analyzer = HealthAnalyzer()
    insights = analyzer.analyze_trends(sample_data)
    print("Insights:", insights)
    
    # Test visualization
    visualizer = HealthVisualizer()
    fig = visualizer.create_heart_rate_chart(sample_data)
    print("Chart created successfully") 