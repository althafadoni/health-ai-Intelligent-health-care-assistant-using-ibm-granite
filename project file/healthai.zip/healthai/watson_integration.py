"""
IBM Watson Integration Module for HealthAI
Handles communication with IBM Watson Machine Learning and Granite model
"""

import os
import json
from typing import Dict, List, Optional
import streamlit as st

# Import IBM Watson Machine Learning components
from ibm_watson_machine_learning.foundation_models import ModelInference
from ibm_watson_machine_learning.foundation_models.extensions.langchain import WatsonxLLM
from ibm_watson_machine_learning.metanames import GenTextParamsMetaNames as GenParams
from ibm_watson_machine_learning.foundation_models.utils.enums import DecodingMethods

class WatsonGraniteClient:
    """Client for IBM Watson Granite model integration using proper SDK"""
    
    def __init__(self, api_key: str, project_id: str):
        self.api_key = api_key
        self.project_id = project_id
        self.model_id = "ibm/granite-3-3-8b-instruct"
        
        # Initialize the model with proper parameters
        self.generate_params = {
            GenParams.DECODING_METHOD: DecodingMethods.SAMPLE,
            GenParams.MAX_NEW_TOKENS: 500,
            GenParams.MIN_NEW_TOKENS: 1,
            GenParams.STOP_SEQUENCES: [],
            GenParams.REPETITION_PENALTY: 1.1,
            GenParams.TEMPERATURE: 0.7,
            GenParams.TOP_P: 0.9
        }
        
        try:
            # Initialize the model inference
            self.model = ModelInference(
                model_id=self.model_id,
                credentials={
                    "apikey": api_key,
                    "url": "https://us-south.ml.cloud.ibm.com"
                },
                params=self.generate_params,
                project_id=project_id
            )
            
            # Create LangChain wrapper
            self.llm = WatsonxLLM(model=self.model)
            
        except Exception as e:
            st.error(f"Failed to initialize IBM Watson model: {str(e)}")
            self.model = None
            self.llm = None
    
    def generate_response(self, prompt: str, max_tokens: int = 500) -> Optional[str]:
        """
        Generate response using IBM Granite model with proper SDK
        """
        if not self.model or not self.llm:
            return self._get_fallback_greeting_response(prompt)
        
        try:
            # Use the LangChain wrapper for better response handling
            response = self.llm(prompt)
            if response and response.strip():
                return response.strip()
            else:
                return self._get_fallback_greeting_response(prompt)
                
        except Exception as e:
            st.error(f"Error generating response: {str(e)}")
            return self._get_fallback_greeting_response(prompt)

    def health_chat_response(self, query: str, context: str = "") -> str:
        # Detect simple greetings (more comprehensive)
        simple_greetings = [
            "hello", "hi", "hey", "good morning", "good afternoon", "good evening", "good night", 
            "how are you", "what's up", "greetings", "good day", "morning", "afternoon", "evening",
            "hello there", "hi there", "hey there", "howdy", "yo", "sup", "what's going on"
        ]
        prompt_lower = query.lower().strip()
        
        # Check if it's a simple greeting (exact match, starts with greeting, or contains only greeting words)
        is_greeting = False
        
        print(f"Checking greeting for: '{prompt_lower}'")
        
        # Check for exact matches
        if prompt_lower in simple_greetings:
            is_greeting = True
            print(f"Exact match found: '{prompt_lower}'")
        # Check if starts with greeting
        elif any(prompt_lower.startswith(greeting + " ") for greeting in simple_greetings):
            is_greeting = True
            print(f"Starts with greeting: '{prompt_lower}'")
        # Check if contains only greeting words (for variations like "hello!" or "hi there!")
        elif any(greeting in prompt_lower for greeting in simple_greetings) and len(prompt_lower.split()) <= 3:
            # Additional check to ensure it's not a health question
            health_keywords = ["symptom", "pain", "fever", "headache", "sick", "ill", "disease", "condition", "treatment", "medicine", "doctor", "hospital"]
            if not any(keyword in prompt_lower for keyword in health_keywords):
                is_greeting = True
                print(f"Short greeting phrase: '{prompt_lower}'")
        
        print(f"Final greeting detection result: {is_greeting}")
        
        # If it's a simple greeting, return friendly response immediately (bypass AI)
        if is_greeting:
            print(f"Greeting detected: '{query}' -> Returning greeting response")
            return self._get_fallback_greeting_response(query)

        # Only proceed with AI if it's not a greeting
        prompt = f"""You are a helpful healthcare assistant. Answer the following health question professionally and accurately.
Always include appropriate medical disclaimers and recommend consulting healthcare professionals when appropriate.

Context: {context}
Question: {query}

Provide a clear, informative response:"""
        
        response = self.generate_response(prompt)
        if response and not self._is_fallback_response(response):
            return response
        else:
            return self._get_fallback_chat_response(query)

    def disease_prediction(self, symptoms: str, patient_data: Optional[Dict] = None) -> str:
        patient_info = ""
        if patient_data:
            patient_info = f"Patient Info: Age {patient_data.get('age', 'N/A')}, Gender {patient_data.get('gender', 'N/A')}"
        
        prompt = f"""You are a medical AI assistant. Analyze the following symptoms and provide potential diagnoses with probability assessments.
Always emphasize that this is for informational purposes only and recommend professional medical consultation.

{patient_info}
Symptoms: {symptoms}

Provide analysis in this format:
1. Most likely conditions with probability percentages
2. Brief explanation of each condition
3. Recommended next steps
4. Medical disclaimer"""
        
        response = self.generate_response(prompt, max_tokens=800)
        if response and not self._is_fallback_response(response):
            return response
        else:
            return self._get_fallback_disease_response(symptoms)

    def treatment_plan_generation(self, condition: str, patient_data: Optional[Dict] = None) -> str:
        patient_info = ""
        if patient_data:
            patient_info = f"Patient Info: Age {patient_data.get('age', 'N/A')}, Gender {patient_data.get('gender', 'N/A')}"
        
        prompt = f"""You are a medical AI assistant. Generate a comprehensive treatment plan for the following condition.
Include medications, lifestyle modifications, follow-up care, and preventive measures.
Always emphasize consulting healthcare providers for personalized treatment.

{patient_info}
Condition: {condition}

Provide treatment plan in this format:
1. Medications (with disclaimers about prescription requirements)
2. Lifestyle Modifications
3. Follow-up Care
4. Preventive Measures
5. Medical disclaimer"""
        
        response = self.generate_response(prompt, max_tokens=1000)
        if response and not self._is_fallback_response(response):
            return response
        else:
            return self._get_fallback_treatment_response(condition)

    def health_insights(self, health_data: Dict) -> str:
        prompt = f"""You are a medical AI assistant. Analyze the following health data and provide insights and recommendations.
Focus on trends, potential concerns, and actionable advice.

Health Data: {json.dumps(health_data, indent=2)}

Provide insights covering:
1. Key observations about health trends
2. Potential health concerns
3. Recommendations for improvement
4. When to seek medical attention"""
        
        response = self.generate_response(prompt, max_tokens=600)
        if response and not self._is_fallback_response(response):
            return response
        else:
            return self._get_fallback_insights_response(health_data)

    def _is_fallback_response(self, response: str) -> bool:
        """Check if the response is a fallback response"""
        fallback_indicators = [
            "Hello! I'm HealthAI",
            "Hi there! I'm here to help",
            "Greetings! I'm your AI health assistant",
            "Hello! Welcome to HealthAI",
            "Hi! I'm your healthcare AI assistant",
            "Good day! I'm HealthAI",
            "Hello there! I'm your AI health companion",
            "Hi! Welcome to your personal health assistant"
        ]
        return any(indicator in response for indicator in fallback_indicators)

    # Fallback responses when IBM Watson is unavailable
    def _get_fallback_greeting_response(self, prompt: str) -> str:
        """Fallback response for simple greetings and basic queries"""
        import random
        
        greeting_responses = [
            "Hello! I'm HealthAI, your intelligent healthcare assistant. How can I help you with your health questions today?",
            "Hi there! I'm here to help you with health-related questions and concerns. What would you like to know?",
            "Greetings! I'm your AI health assistant. Feel free to ask me any health questions or concerns you may have.",
            "Hello! Welcome to HealthAI. I'm here to provide health information and guidance. How can I assist you today?",
            "Hi! I'm your healthcare AI assistant. I can help with health questions, symptom analysis, and treatment information. What's on your mind?",
            "Good day! I'm HealthAI, ready to help you with health-related queries. What would you like to discuss?",
            "Hello there! I'm your AI health companion. I can assist with health questions, disease information, and wellness advice. How may I help?",
            "Hi! Welcome to your personal health assistant. I'm here to provide health guidance and answer your medical questions."
        ]
        
        return random.choice(greeting_responses)

    def _get_fallback_chat_response(self, query: str) -> str:
        fallback_responses = [
            "I understand your health concern. While I can provide general information, it's important to consult with a healthcare professional for personalized medical advice.",
            "Thank you for sharing your health question. For accurate medical guidance, I recommend consulting with a qualified healthcare provider who can assess your specific situation.",
            "Your health question is important. While I can offer general information, please seek professional medical advice for proper diagnosis and treatment."
        ]
        import random
        return random.choice(fallback_responses)

    def _get_fallback_disease_response(self, symptoms: str) -> str:
        return f"""
        Based on the symptoms you've described ({symptoms}), I can provide some general information:

        **Common Considerations:**
        - Many symptoms can have multiple causes
        - Individual cases vary significantly
        - Professional medical evaluation is essential

        **Recommended Next Steps:**
        1. Monitor your symptoms for 24-48 hours
        2. Keep a symptom diary
        3. Schedule an appointment with a healthcare provider
        4. Seek immediate care if symptoms worsen

        **Important Disclaimer:**
        This analysis is for informational purposes only and should not replace professional medical diagnosis. 
        Always consult with a healthcare provider for proper evaluation and treatment.
        """

    def _get_fallback_treatment_response(self, condition: str) -> str:
        return f"""
        **Treatment Plan for {condition}**

        **General Recommendations:**
        - Follow your healthcare provider's prescribed treatment
        - Maintain regular follow-up appointments
        - Monitor your condition and report changes
        - Adhere to medication schedules if prescribed

        **Lifestyle Considerations:**
        - Maintain a balanced diet
        - Regular exercise as recommended
        - Adequate sleep and stress management
        - Avoid smoking and excessive alcohol

        **Important Disclaimer:**
        This treatment plan is for informational purposes only. Always follow your healthcare provider's 
        prescribed treatment regimen and consult them before making any changes to your medical care.
        """

    def _get_fallback_insights_response(self, health_data: Dict) -> str:
        return """
        **Health Insights Summary:**

        **General Observations:**
        - Continue monitoring your health metrics regularly
        - Maintain healthy lifestyle habits
        - Schedule regular check-ups with your healthcare provider

        **Recommendations:**
        - Keep track of any concerning trends
        - Discuss significant changes with your doctor
        - Follow preventive care guidelines

        **When to Seek Medical Attention:**
        - Sudden changes in vital signs
        - New or worsening symptoms
        - Concerns about your health status

        **Note:** These insights are general recommendations. Always consult with healthcare professionals for personalized medical advice.
        """

def init_watson_client() -> Optional[WatsonGraniteClient]:
    api_key = os.getenv('WATSONX_API_KEY')
    project_id = os.getenv('WATSONX_PROJECT_ID')
    if not api_key or not project_id:
        st.warning("IBM Watson credentials not found. Using fallback responses.")
        return None
    try:
        return WatsonGraniteClient(api_key, project_id)
    except Exception as e:
        st.error(f"Failed to initialize IBM Watson client: {str(e)}")
        return None

if __name__ == "__main__":
    client = init_watson_client()
    if client:
        response = client.health_chat_response("What are the symptoms of diabetes?")
        print("Test Response:", response)
    else:
        print("IBM Watson client not initialized - check credentials") 